        print(self.wins)
        print(self.losses)
        print(self.average)